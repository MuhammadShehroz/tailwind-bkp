import DocumentSerializer from 'frontend/serializers/document';

export default DocumentSerializer.extend();
