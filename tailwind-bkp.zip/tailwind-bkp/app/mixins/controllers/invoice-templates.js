import Mixin from '@ember/object/mixin';
import DocumentsController from 'frontend/mixins/controllers/documents/index';

export default Mixin.create(DocumentsController);
