import { module, test } from 'qunit';

module('Unit | Utility | file', function () {
  test('it works', function (assert) {
    assert.ok(1);
  });
});
