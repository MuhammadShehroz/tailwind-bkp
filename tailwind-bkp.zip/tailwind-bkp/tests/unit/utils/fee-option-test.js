import feeOption from 'frontend/utils/fee-option';
import { module, test } from 'qunit';

module('Unit | Utility | fee-option', function () {
  // TODO: Replace this with your real tests.
  test('it works', function (assert) {
    let result = feeOption();
    assert.ok(result);
  });
});
