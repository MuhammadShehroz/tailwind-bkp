import { module, test } from 'qunit';
import { setupTest } from 'ember-qunit';

module('Unit | Route | account/profile/delete', function (hooks) {
  setupTest(hooks);

  test('it exists', function (assert) {
    let route = this.owner.lookup('route:account/profile/delete');
    assert.ok(route);
  });
});
