module.exports = {
  env: {
    embertest: true
  },

  rules: {
    'import/no-relative-parent-imports': 'off'
  }
};
