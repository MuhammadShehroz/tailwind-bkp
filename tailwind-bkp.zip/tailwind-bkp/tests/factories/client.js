import FactoryGuy from 'ember-data-factory-guy';

FactoryGuy.define('client', {
  default: {}
});
