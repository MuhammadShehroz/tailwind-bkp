import FactoryGuy from 'ember-data-factory-guy';

FactoryGuy.define('delivery', {
  default: {}
});
